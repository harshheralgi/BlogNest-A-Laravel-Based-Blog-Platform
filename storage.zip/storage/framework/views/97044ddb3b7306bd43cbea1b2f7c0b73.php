<?php Basset::basset("https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"); ?>
<?php Basset::basset('https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/js/bootstrap.min.js'); ?>
<?php Basset::basset('https://cdn.jsdelivr.net/npm/@coreui/coreui@2.1.16/dist/js/coreui.js'); ?>
<?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\vendor/backpack/theme-coreuiv2/resources/views/inc/theme_scripts.blade.php ENDPATH**/ ?>