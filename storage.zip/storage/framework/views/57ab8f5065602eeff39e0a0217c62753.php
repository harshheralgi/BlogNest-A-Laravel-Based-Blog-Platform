<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BlogNest</title>
    <style>
        body{
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 16px;
    line-height: 1.6em;
    margin:0;
}

.heading{
    color: rgb(249, 237, 0);
}

.container{
    width: 80%;
    margin: 0 auto;
    padding-bottom: 15px;
    overflow: hidden;
}

#main-header{
    background-color: #343a40;
    color: #ffffff;
}

#navbar{
    display: flex;

}

a{
    text-decoration: none;
    color: #ffffff;
}
a:hover{
    color: red;

}

ul{
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    gap: 40px;  
}

.hero-div{
    /*background-image: url(blog.jpg);*/
    background-color: #fff3e0;
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    padding: 50px;
}

.hero-heading{
    display: flex;
    justify-content: center; 
}

.hero-para{
    display: flex;
    justify-content: center; 
}

.card-container {
  display: flex;
  justify-content: center;
  gap: 20px;
  padding: 40px;
  flex-wrap: wrap; /* wraps cards on smaller screens */
}

.card {
  width: 250px;
  padding: 25px;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s ease;
  text-align: center;
}

.card:hover {
  transform: translateY(-5px);
}

.card a {
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
}

.card h2 {
  color: #bf360c;
}
    </style>
</head>
<body>
    <header id="main-header">
        <div class="container">  
            <h2 class="heading">BlogNest</h2>
            <nav class="navbar">
                <ul class="nav-links">
                    <li><a href="<?php echo e(route('layout.app')); ?>">Blogs</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                    <li><a href="<?php echo e(url('admin/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('admin/register')); ?>">Register</a></li>
                </ul>
            </nav> 
        </div> 
    </header>
    <div class="hero-div">
        <section class="hero-section">
            <h1 class="hero-heading">Welcome to BlogNest</h1>
                <p class="hero-para">Read blogs from inspiring voices across tech, life, design, and more.</p>
        </section>
    </div>
    </div>


    <div class="card-container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <h2><?php echo e($post->title); ?></h2>
            <h4>by <?php echo e($post->author); ?></h4>
            <p>
                <?php echo e(Str::limit(strip_tags($post->content), 180, '...')); ?>

            </p>
            <a href="<?php echo e(route('post.show', $post->id)); ?>">Read More →</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>