<li class="nav-item">
    <a <?php echo e($attributes->merge(['class' => 'nav-link', 'href' => $link])); ?>>
        <?php if($icon != null): ?><i class="nav-icon <?php echo e($icon); ?>"></i><?php endif; ?>
        <?php if($title!=null): ?> <span><?php echo e($title); ?></span><?php endif; ?>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\vendor/backpack/theme-coreuiv2/resources/views/components/menu-item.blade.php ENDPATH**/ ?>