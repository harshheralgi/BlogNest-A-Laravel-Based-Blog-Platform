<?php $__env->startSection('content'); ?>
<div class="card-container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <h2><?php echo e($post->title); ?></h2>
            <h4>by <?php echo e($post->author->name ?? 'Unknown'); ?></h4>
            <p>
                <?php echo e(Str::limit(strip_tags($post->content), 180, '...')); ?>

            </p>
            <a href="<?php echo e(route('post.show', $post->slug)); ?>">Read More →</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\resources\views/home.blade.php ENDPATH**/ ?>