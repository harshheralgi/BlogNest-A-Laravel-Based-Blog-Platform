<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BlogNest</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .contact-container {
        max-width: 700px;
        margin: 60px auto;
        background-color: #ffffff;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
        color: #333;
        }

        .contact-container h1 {
        font-size: 2.2em;
        color: #2c3e50;
        margin-bottom: 10px;
        }

        .contact-container p {
        font-size: 1em;
        margin-bottom: 20px;
        line-height: 1.6;
        }

        .contact-form {
        display: flex;
        flex-direction: column;
        }

        .contact-form label {
        margin-bottom: 6px;
        font-weight: 600;
        margin-top: 20px;
        }

        .contact-form input,
        .contact-form textarea {
        padding: 12px;
        font-size: 1em;
        border: 1px solid #ccc;
        border-radius: 6px;
        resize: vertical;
        }

        .contact-form button {
        margin-top: 20px;
        padding: 12px;
        font-size: 1em;
        background-color: #16a085;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        }

        .contact-form button:hover {
        background-color: #138d75;
        }

        .contact-info {
        margin-top: 30px;
        font-size: 0.95em;
        color: #555;
        }

        .contact-info a {
        text-decoration: none;
        color: #16a085;
        }

        .contact-info a:hover {
        text-decoration: underline;
        }
                body{
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 16px;
    line-height: 1.6em;
    margin:0;
}

.heading{
    color: rgb(249, 237, 0);
}

.container{
    width: 80%;
    margin: 0 auto;
    padding-bottom: 15px;
    overflow: hidden;
}

#main-header{
    background-color: #343a40;
    color: #ffffff;
}

#navbar{
    display: flex;

}

a{
    text-decoration: none;
    color: #ffffff;
}
a:hover{
    color: red;

}

ul{
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    gap: 40px;  
}

.hero-div{
    /*background-image: url(blog.jpg);*/
    background-color: #fff3e0;
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    padding: 50px;
}

.hero-heading{
    display: flex;
    justify-content: center; 
}

.hero-para{
    display: flex;
    justify-content: center; 
}

.card-container {
  display: flex;
  justify-content: center;
  gap: 20px;
  padding: 40px;
  flex-wrap: wrap; /* wraps cards on smaller screens */
}

.card {
  width: 250px;
  padding: 25px;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s ease;
  text-align: center;
}

.card:hover {
  transform: translateY(-5px);
}

.card a {
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
}

.card h2 {
  color: #bf360c;
}
    </style>
</head>
<body>
    <header id="main-header">
        <div class="container">  
            <h2 class="heading">BlogNest</h2>
            <nav class="navbar">
                <ul class="nav-links">
                    <li><a href="<?php echo e(route('layout.app')); ?>">Blogs</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                    <li><a href="<?php echo e(url('admin/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('admin/register')); ?>">Register</a></li>
                </ul>
            </nav> 
        </div> 
    </header>
      <div class="contact-container">
    <h1>Contact Us</h1>
    <p>We'd love to hear from you! Whether you have a question, feedback, or want to collaborate — reach out to us below.</p>
    
    <form class="contact-form" action="#" method="POST">
      <label for="name">Name</label>
      <input type="text" id="name" name="name" placeholder="Your Name" required />

      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="you@example.com" required />

      <label for="message">Message</label>
      <textarea id="message" name="message" rows="6" placeholder="Type your message here..." required></textarea>

      <button type="submit">Send Message</button>
    </form>

    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\resources\views/contact.blade.php ENDPATH**/ ?>