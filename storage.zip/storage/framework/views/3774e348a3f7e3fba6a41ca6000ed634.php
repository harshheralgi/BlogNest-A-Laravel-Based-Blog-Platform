


<?php /**PATH C:\xampp\htdocs\laravel\hobbyProject-app\vendor/backpack/theme-coreuiv2/resources/views/inc/topbar_left_content.blade.php ENDPATH**/ ?>