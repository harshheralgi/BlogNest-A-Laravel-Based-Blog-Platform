<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | BlogNest</title>
    <link rel="stylesheet" href="styles.css">
    <style>
      body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
        color: #333;
      }

      .about-container {
        max-width: 900px;
        margin: 60px auto;
        background-color: #ffffff;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
      }

      .about-container h1 {
        font-size: 2.5em;
        color: #2c3e50;
        margin-bottom: 10px;
      }

      .about-container h2 {
        font-size: 1.5em;
        color: #16a085;
        margin-bottom: 20px;
      }

      .about-container h3 {
        font-size: 1.3em;
        color: #34495e;
        margin-top: 30px;
      }

      .about-container p {
        line-height: 1.7;
        margin: 15px 0;
      }

      .about-container ul {
        padding-left: 20px;
        margin: 10px 0 20px;
      }

      .about-container ul li {
        margin-bottom: 10px;
      }
      body{
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 16px;
    line-height: 1.6em;
    margin:0;
}

.heading{
    color: rgb(249, 237, 0);
}

.container{
    width: 80%;
    margin: 0 auto;
    padding-bottom: 15px;
    overflow: hidden;
}

#main-header{
    background-color: #343a40;
    color: #ffffff;
}

#navbar{
    display: flex;

}

a{
    text-decoration: none;
    color: #ffffff;
}
a:hover{
    color: red;

}

ul{
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    gap: 40px;  
}

.hero-div{
    /*background-image: url(blog.jpg);*/
    background-color: #fff3e0;
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    padding: 50px;
}

.hero-heading{
    display: flex;
    justify-content: center; 
}

.hero-para{
    display: flex;
    justify-content: center; 
}

.card-container {
  display: flex;
  justify-content: center;
  gap: 20px;
  padding: 40px;
  flex-wrap: wrap; /* wraps cards on smaller screens */
}

.card {
  width: 250px;
  padding: 25px;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s ease;
  text-align: center;
}

.card:hover {
  transform: translateY(-5px);
}

.card a {
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
}

.card h2 {
  color: #bf360c;
}
    </style>
</head>
<body>
    <header id="main-header">
        <div class="container">  
            <h2 class="heading">BlogNest</h2>
            <nav class="navbar">
                <ul class="nav-links">
                    <li><a href="{{route('layout.app')}}">Blogs</a></li>
                    <li><a href="{{route('about')}}">About</a></li>
                    <li><a href="{{route('contact')}}">Contact Us</a></li>
                    <li><a href="{{url('admin/login')}}">Login</a></li>
                    <li><a href="{{url('admin/register')}}">Register</a></li>
                </ul>
            </nav> 
        </div> 
    </header>
    <body>
  <div class="about-container">
    <h1>About Us</h1>
    <h2>Welcome to BlogNest – Where Ideas Take Flight.</h2>

    <p>
      At BlogNest, we believe that every voice matters and every story deserves to be heard. 
      Founded with a vision to create a platform for passionate writers, curious readers, and 
      lifelong learners, BlogNest is your digital haven for insightful blogs, meaningful discussions, 
      and inspiring perspectives.
    </p>

    <h3>Our Mission</h3>
    <p>
      To empower individuals by providing a creative space where thoughts, experiences, and 
      expertise can be shared freely and thoughtfully. We strive to build a community that 
      values authenticity, growth, and knowledge.
    </p>

    <h3>What We Offer</h3>
    <ul>
      <li><strong>Diverse Content:</strong> Covering tech, lifestyle, personal growth, and more.</li>
      <li><strong>User-Friendly Experience:</strong> Clean design for smooth reading and writing.</li>
      <li><strong>Community Engagement:</strong> Comment, share, and contribute easily.</li>
    </ul>

    <h3>Why BlogNest?</h3>
    <p>
      The name <em>BlogNest</em> symbolizes a safe and nurturing space for ideas to grow and thrive. 
      Just like a nest supports young birds, we support writers at every level—whether you're 
      just starting or already soaring.
    </p>

    <h3>Join Us</h3>
    <p>
      Whether you're here to read, write, or explore, BlogNest welcomes you. Dive into our blogs, 
      share your insights, and become part of a vibrant, thoughtful community.
    </p>
    </div>
    </body>
</html>