<style>
body {
    font-family: 'Georgia', serif;
    background-color: #f9f9f9;
    color: #333;
    line-height: 1.8;
    padding: 40px;
    max-width: 960px;
    margin: auto;
}

h1 {
    font-size: 2.5em;
    font-weight: bold;
    color: #2c3e50;
    margin-bottom: 10px;
}

h3 {
    font-size: 1.5em;
    font-weight: bold;
    color: #34495e;
    margin-top: 0;
}

p {
    font-size: 1.1em;
    text-align: justify;
    margin-bottom: 20px;
}

a {
    color: #6a1b9a;
    text-decoration: none;
    font-weight: bold;
}

a:hover {
    text-decoration: underline;
}
</style>
<h1>{{ $post->title }}</h1>
<h3>By {{$post->author}}</h3>
<div>
    <p>{!! $post->content !!}</p>
        <a href="{{ url('/') }}">← Back to Home</a>
</div>
