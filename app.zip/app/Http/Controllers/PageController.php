<?php

namespace App\Http\Controllers;
use App\Models\Post; 

use Illuminate\Http\Request;

class PageController extends Controller
{

    public function index()
    {
    $posts = Post::all();  // fetch all posts from DB
    return view('layouts.app', compact('posts')); // pass $posts to the view
    }


    public function about(){
        return view('about');
    }

    public function contact(){
        return view('contact');
    }
    public function post(){
        return view('post', compact('post'));        
    }
        public function show($id)
{
    $post = Post::findOrFail($id);
    return view('post', compact('post')); 
}

}
